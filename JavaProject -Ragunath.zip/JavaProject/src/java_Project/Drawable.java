package java_Project;

public interface Drawable {

}
