package java_Project;

public class Hybird_Inheritance_Example {
    public static void main(String[] args) {
        Circle circle = new Circle(null, 0);
        Rectangle rectangle = new Rectangle();
        Polygon polygon = new Polygon();

        circle.draw();      // Output: Drawing a circle
        rectangle.draw();   // Output: Drawing a rectangle
        polygon.draw();     // Output: Drawing a polygon
    }
}
