package java_Project;

public class Polygon {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public void draw() {
		// TODO Auto-generated method stub
		
	}

}
