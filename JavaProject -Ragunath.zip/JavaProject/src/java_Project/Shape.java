package java_Project;

public class Shape {

}
